// 引用使用es6的module引入和定义
// 全局变量以g_开头
// 私有函数以_开头

import { Config } from 'config.js';

class Token {
  constructor() {
    //this.verifyUrl = 'http://ds.sharexwd.top/api/v1/token/user';
    this.tokenUrl = 'http://ds.sharexwd.top/api/v1/token/user';
  }

  verify() {
    var token = wx.getStorageSync('token');
    if (!token) {
      this.getTokenFromServer();
    }
    else {
      // this._veirfyFromServer(token);
    }
  }

  // _veirfyFromServer(token) {
  //   var that = this;
  //   wx.request({
  //     url: that.verifyUrl,
  //     method: 'POST',
  //     header: {
  //       'content-type': 'application/json',
  //       'token': wx.getStorageSync('token')
  //     },
  //     data: {
  //       token: token
  //     },
  //     success: function (res) {
  //       var valid = res.data.isValid;
  //       if (!valid) {
  //         that.getTokenFromServer();
  //       }
  //     }
  //   })
  // }

  getTokenFromServer(callBack) {
    var that = this;
    wx.login({
      success: function (res) {
        console.log(res)
        wx.request({
          url: that.tokenUrl,
          method: 'POST',
          header: {
            'content-type': 'application/json',
            'token': wx.getStorageSync('token')
          },
          data: {
            code: res.code
          },
          success: function (res) {
            console.log(res)
            wx.setStorageSync('token', res.data.token);
            callBack && callBack(res.data.token);
          }
        })
      }

    })
  }
}

export { Token };